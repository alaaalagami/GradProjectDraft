with open('next_scene.txt', 'r') as next_file:
    next = next_file.read().strip()
    print(next)
